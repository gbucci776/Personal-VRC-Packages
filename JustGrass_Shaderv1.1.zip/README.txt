========================================
 JustGrass — README (v1.1)
 -V I A-
========================================

LICENSE SUMMARY
--------------------------------
You may use this shader in unlimited personal and commercial projects.
Do not resell, redistribute, or repackage the shader source itself.
This is a summary only see TermsOfService.txt for the
full terms, also viewable on the Gumroad product page.


REQUIREMENTS
--------------------------------
- Unity 2022.3.22f1 (other versions untested there's no guarantee of compatibility)
- Built-in Render Pipeline ONLY. This shader will NOT work in URP or HDRP.
- Built for VRChat worlds on PC/Windows.
- Assumes working knowledge of Unity and Blender. This shader requires
  some technical setup on your end — see "Tips for Setup" below.


HOW TO INSTALL
--------------------------------
1. Install LWGUI (required for the custom shader inspector UI):
        Window > Package Manager > Add > Add package from git URL
        https://github.com/JasonMa0012/LWGUI.git
2. Import the JustGrass.unitypackage into your Unity project.
3. That's it! No other packages are required. Everything else needed
   is included in this package.


TIPS FOR SETUP
--------------------------------
- Use TWO separate meshes: one for your actual terrain/ground collision,
  and a second, separate mesh that the JustGrass shader is applied to.
  Do not apply this shader directly to your terrain mesh.
- Grass mesh topology should be clean and EVENLY SPACED. Uneven or
  poorly distributed topology will cause uneven, clumpy grass,
  since blade placement is derived from the mesh surface.
- This shader uses tessellation and geometry shaders to generate grass
  blades on the GPU so it does not use pre-placed blade meshes.
- Included: player grass collision/displacement, and a custom object
  collision system for non-player deformers. See the shader's
  Collision & Trails group in the inspector to configure.


KNOWN LIMITATIONS
--------------------------------
- Does NOT render on Quest / mobile VRChat. Tessellation and geometry
  shaders are not supported on Quest's mobile GPU pipeline. This shader
  is PC/Windows only.
- May not behave as expected on Unity Terrain objects. Recommended to
  use a standard mesh (see "Tips for Setup" above) rather than applying
  directly to a Terrain component.
- You are responsible for integrating this shader into your project.
  Support covers the shader itself, not general Unity/Blender/VRChat
  setup knowledge.


SUPPORT
--------------------------------
Questions, issues, or feature feedback? Head to my Discord — the
invite link is on my Gumroad page. Please check
Known Limitations above before reporting an issue.


CREDITS
--------------------------------
Stylized grass rendering techniques referenced and adapted from:
Daniel Ilett — "Stylized Grass" tutorial series
https://danielilett.com/2021-08-24-tut5-17-stylised-grass/

LWGUI custom shader inspector by JasonMa0012
https://github.com/JasonMa0012/LWGUI


========================================
 Thank you for supporting me!
========================================